import React from 'react'
import { Outlet } from 'react-router'

export default function Setting() {
  return (
    <> <div>Setting</div>
    <Outlet/>
    </>
   
  )
}
